import React, { Component } from 'react';

class App extends Component {

    constructor(props) {
        super(props);
        this.addClick = this.addClick.bind(this);
    }    
    addClick(num) {
        this.props.ParentsFunction(num);
    }
     
    render() {
        return (
            <div>
                <input type="button" value="1" onClick={this.addClick.bind(this, 1)}/>
                <input type="button" value="2" onClick={this.addClick.bind(this, 2)}/>
                <input type="button" value="3" onClick={this.addClick.bind(this, 3)}/>
            </div>
        )
    }
}

module.exports = App;