import React, { Component } from 'react';
import App from'./app'
import Operator from './Operator'
class Result extends Component {
    constructor(props) {
        super(props);
        this.state = {caloper: '', calVal:0, total:0, log:[], seq:0};
        this.handleChildValueCallback = this.handleChildValueCallback.bind(this);
        this.handleChildOperatorCallback = this.handleChildOperatorCallback.bind(this);
        this.revertLog = this.revertLog.bind(this);
    }    
    revertLog(seq)
    {
     this.setState((prevState, props) => {
            var reverlog = this.state.log.filter(function(obj, index){
                return obj.seq == seq;
            });
            var otherlog = this.state.log.filter(function(obj, index){
                return obj.seq != seq;
            });
            
            return {
                caloper:'',
                calVal:0,
                total:this.state.total + eval(reverlog[0].calVal) + reverlog[0].calVal,
                log:otherlog
            }
        });   
    }
    handleChildValueCallback(num){    
        this.setState((prevState, props) => {
            let newState = null;
            let id =prevState.seq+1;
            let logg = prevState.log;
            if(prevState.caloper=='+')
            {
                newState = {total:prevState.total+num,calVal:num,caloper:prevState.caloper,log:logg,seq:id};                
                const newlog = Object.assign({}, id, newState, {preCalVal:prevState.total});
                delete newlog.log;
                logg.push(newlog);
            }
            else if(prevState.caloper=='-')
            {
                newState = {total:prevState.total-num,calVal:num,caloper:prevState.caloper,log:logg,seq:id};
                const newlog = Object.assign({}, id, newState, {preCalVal:prevState.total});
                delete newlog.log;
                logg.push(newlog);
            }
            else
            {
                newState = {calVal:num};
            }

            return newState;
        });  
    }
    handleChildOperatorCallback(oper){    
        this.setState((prevState, props) => {
            let newState = null;
            let id =prevState.seq+1;
            let logg = prevState.log;
            if(oper=='+')
            {
                newState = {total:prevState.total+prevState.calVal,calVal:prevState.calVal,caloper:oper,log:logg,seq:id};
                const newlog = Object.assign({}, id, newState, {preCalVal:prevState.total});
                delete newlog.log;
                logg.push(newlog);
            }
            else if(oper=='-')
            {
                newState = {total:prevState.total-prevState.calVal,calVal:prevState.calVal,caloper:oper,log:logg,seq:id};
                const newlog = Object.assign({}, id, newState, {preCalVal:prevState.total});
                delete newlog.log;
                logg.push(newlog);
            }

            return newState;
        });
    }
    
    render() {

        function ObjectRow(props)
        {
            return <div key={props.log[i].seq} onClick={this.revertLog.bind(this, props.log[i].seq)}>{ props.log[i].preCalVal +" "+ props.log[i].caloper +" "+ props.log[i].calVal + " = " + props.log[i].total}</div>;
        }

        let record = [];
        for(var i=0;i<this.state.log.length;i++)
            if(this.state.log[i]!=null)
                record.push(ObjectRow(this.state));
        
        return (
            <div>
                <App ParentsFunction={this.handleChildValueCallback}/>
                <Operator ParentsFunction={this.handleChildOperatorCallback}/>
                {this.state.total}<br/>
                {record}
                
            </div>
            
        )
    }
}

module.exports = Result;