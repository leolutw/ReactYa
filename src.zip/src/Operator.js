import React, { Component } from 'react';

class Operator extends Component {
    constructor(props) {
        super(props);
        this.addClick = this.addClick.bind(this);
        this.reduceClick = this.reduceClick.bind(this);
    }    
    addClick(operator) {
        this.props.ParentsFunction(operator);
    }
    reduceClick(e) {
        this.props.ParentsFunction.bind(this, operator);
    }
    render() {
        return (
            <div>
                <input type="button" value="+" onClick={this.addClick.bind(this, '+')}/>
                <input type="button" value="-" onClick={this.addClick.bind(this, '-')}/>
            </div>
            
        )
    }
}

module.exports = Operator;